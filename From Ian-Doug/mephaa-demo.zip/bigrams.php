<?php

$freq = array();
$file = "./mephaa-3-unicode-klaized.txt";
$fpin = fopen ("$file", "r") or die("Can't open $file, aborting.\n"); # file

$outfile = "./bigrams.txt";
$fpout = fopen ("$outfile", "w") or die("Can't open $outfile, aborting.\n"); # file


while ($line = fgets ($fpin, 20000))
  {  
   # get the length. Careful for foreign characters.
    $line = preg_replace("/\s*$/", '', $line);  # kill junk at end better than chop.  
    $one = $two = "";

  foreach(preg_split("//u",$line,-1,PREG_SPLIT_NO_EMPTY) as $char)   
    {
      
      $one = $two;
      $two = $char;
      if ($one != "")
       {
        $bi = $one . $two;
        $bi = preg_replace("/\s/u","⍽",$bi);
      
      if (isset($freq[$bi]))
        {
         $freq[$bi]++;
        }
       else
        {
         $freq[$bi] = 1;
        };
       }
     }
            #print "$query\n";
    }; 

    
    arsort($freq);
    foreach ($freq as $bi => $count)
     {
#      $uni = json_encode($char);
#     if (strlen($uni) > 4) # already encoded
#        {
#         $thischar = "U+" . strtoupper(substr($uni,3,4));
#        }
#     else # low ascii
#        {
#         $uni = ord($char);
#         $thischar = "U+" . strtoupper(str_pad(dechex($uni),4,"0",STR_PAD_LEFT)); # to match strings by otfinfo later
#        }

      print "$bi :  $count\n";
      fwrite($fpout, "$bi :  $count\n");
     }

     print "-----------------------------------\n";
     
     
?>
