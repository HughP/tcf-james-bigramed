<?php
# replace under macron diacritic letters with single char.

$file = "./mephaa3-unicode.txt";
$fpin = fopen ("$file", "r") or die("Can't open $file, aborting.\n"); # file

$outfile = "./mephaa-3-unicode-klaized.txt";
$fpout = fopen ("$outfile", "w") or die("Can't open $outfile, aborting.\n"); # file

while ($line = fgets ($fpin, 4096))
  {  
    $line = preg_replace("/\s*$/", '', $line);  # kill junk at end better than chop.

    $line = preg_replace('/\x{0061}\x{0331}/u','ā',$line);  # a
    $line = preg_replace('/\x{0041}\x{0331}/u','Ā',$line);  # A
     
    $line = preg_replace('/\x{0065}\x{0331}/u','ē',$line);  # e
    $line = preg_replace('/\x{0045}\x{0331}/u','Ē',$line);  # E

    $line = preg_replace('/\x{0069}\x{0331}/u','ī',$line);  # i
    $line = preg_replace('/\x{0049}\x{0331}/u','Ī',$line);  # I
     
    $line = preg_replace('/\x{006f}\x{0331}/u','ō',$line);  # o
    $line = preg_replace('/\x{004f}\x{0331}/u','Ō',$line);  # O
    
    $line = preg_replace('/\x{0075}\x{0331}/u','ū',$line);  # u
    $line = preg_replace('/\x{0055}\x{0331}/u','Ū',$line);  # U

    # others
    $line = preg_replace('/\x{feff}/u','',$line);  # u
    $line = preg_replace('/<</u','«',$line);  # u
    $line = preg_replace('/>>/u','»',$line);  # u
    $line = preg_replace('/</u','‹',$line);  # u
    $line = preg_replace('/>/u','›',$line);  # u
    
    #$line = preg_replace('/\x{a78b}/u','ꞌ',$line);  # capital saltillo -> lower...  leave as is for now.
    
    fwrite($fpout, "$line\n");
  }   
?>
